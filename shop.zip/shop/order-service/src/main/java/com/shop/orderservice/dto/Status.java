package com.shop.orderservice.dto;

public enum Status {
    NEW,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
