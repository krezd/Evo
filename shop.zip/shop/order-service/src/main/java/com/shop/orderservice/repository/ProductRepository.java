package com.shop.orderservice.repository;

import com.shop.orderservice.model.Order;
import com.shop.orderservice.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    void deleteAllByOrder(Order order);
}
