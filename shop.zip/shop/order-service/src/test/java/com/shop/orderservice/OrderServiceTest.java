package com.shop.orderservice;
import com.shop.orderservice.dto.*;
import com.shop.orderservice.model.*;
import com.shop.orderservice.repository.OrderRepository;
import com.shop.orderservice.repository.ProductRepository;
import com.shop.orderservice.service.OrderService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private RestTemplate restTemplate;

    @Spy
    @InjectMocks
    private OrderService orderService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void testUpdateByName_Success() {
        Order order = new Order();
        order.setStatus(Status.NEW);
        order.setProductList(new ArrayList<>());
        when(orderRepository.existsById(anyLong())).thenReturn(true);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        ResponseEntity<?> successResponse = new ResponseEntity<>(HttpStatus.OK);
        doReturn(successResponse).when(orderService).returnProduct(anyList());

        doNothing().when(productRepository).deleteAllByOrder(any(Order.class));

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        List<ProductRequestByName> products = new ArrayList<>();
        ProductRequestByName product1 = new ProductRequestByName();
        product1.setName("Product1");
        product1.setQuantity(1);
        products.add(product1);
        orderRequestByName.setProducts(products);

        ResponseEntity<String> userExistResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userExistResponse);

        Order newOrder = new Order();
        ResponseEntity<Order> createdOrderResponse = new ResponseEntity<>(newOrder, HttpStatus.CREATED);

        doReturn(createdOrderResponse).when(orderService).createByName(anyLong(), any(OrderRequestByName.class), anyLong());

        ResponseEntity<?> response = orderService.updateByName(orderRequestByName, 1L);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(newOrder, response.getBody());
    }

    @Test
    public void testUpdateByName_OrderNotFound() {
        when(orderRepository.existsById(anyLong())).thenReturn(false);

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        ResponseEntity<?> response = orderService.updateByName(orderRequestByName, 1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testUpdateByName_OrderCancelled() {
        Order order = new Order();
        order.setStatus(Status.CANCELLED);
        when(orderRepository.existsById(anyLong())).thenReturn(true);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        ResponseEntity<?> response = orderService.updateByName(orderRequestByName, 1L);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("The order has been cancelled and cannot be changed, place a new order", response.getBody());
    }

    @Test
    public void testUpdateByName_ReturnProductFailed() {
        Order order = new Order();
        order.setStatus(Status.NEW);
        order.setProductList(new ArrayList<>());
        when(orderRepository.existsById(anyLong())).thenReturn(true);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        ResponseEntity<?> failResponse = new ResponseEntity<>("Return product failed", HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(failResponse).when(orderService).returnProduct(anyList());

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        ResponseEntity<?> response = orderService.updateByName(orderRequestByName, 1L);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Return product failed", response.getBody());
    }

    @Test
    public void testUpdateStatus_OrderNotFound() {
        when(orderRepository.findById(anyLong())).thenReturn(Optional.empty());

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            orderService.updateStatus(1L, Status.NEW);
        });

        assertEquals("Order not found with id: 1", exception.getMessage());
    }

    @Test
    public void testUpdateStatus_OrderCancelled() {
        Order order = new Order();
        order.setStatus(Status.CANCELLED);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        ResponseEntity<?> response = orderService.updateStatus(1L, Status.NEW);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("The order has been cancelled and cannot be changed, place a new order", response.getBody());
    }

    @Test
    public void testUpdateStatus_CancelOrder_Success() {
        Order order = new Order();
        order.setStatus(Status.NEW);
        order.setProductList(new ArrayList<>());
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        ResponseEntity<?> successResponse = new ResponseEntity<>(HttpStatus.OK);
        doReturn(successResponse).when(orderService).returnProduct(anyList());

        ResponseEntity<?> response = orderService.updateStatus(1L, Status.CANCELLED);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(order, response.getBody());
        assertEquals(Status.CANCELLED, order.getStatus());
    }

    @Test
    public void testUpdateStatus_CancelOrder_ReturnProductFail() {
        Order order = new Order();
        order.setStatus(Status.NEW);
        order.setProductList(new ArrayList<>());
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        ResponseEntity<?> failResponse = new ResponseEntity<>("Return product failed", HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(failResponse).when(orderService).returnProduct(anyList());

        ResponseEntity<?> response = orderService.updateStatus(1L, Status.CANCELLED);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Return product failed", response.getBody());
        verify(orderRepository, never()).save(any(Order.class));
    }

    @Test
    public void testUpdateStatus_Success() {
        Order order = new Order();
        order.setStatus(Status.NEW);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        ResponseEntity<?> response = orderService.updateStatus(1L, Status.SHIPPED);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(order, response.getBody());
        assertEquals(Status.SHIPPED, order.getStatus());
    }

    @Test
    public void testFindAll() {
        List<Order> orders = new ArrayList<>();
        orders.add(new Order());
        orders.add(new Order());
        when(orderRepository.findAll()).thenReturn(orders);

        ResponseEntity<List<Order>> response = orderService.findAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(orders, response.getBody());
    }

    @Test
    public void testFindById_OrderExists() {
        Order order = new Order();
        order.setOrderId(1L);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));
        when(orderRepository.existsById(anyLong())).thenReturn(true);


        ResponseEntity<Order> response = orderService.findById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Optional.of(order), response.getBody());
        verify(orderRepository, times(1)).findById(1L);
        verify(orderRepository, times(1)).existsById(1L);

    }

    @Test
    public void testFindById_OrderNotExists() {
        when(orderRepository.existsById(anyLong())).thenReturn(false);

        ResponseEntity<Order> response = orderService.findById(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(orderRepository, times(1)).existsById(1L);

    }

    @Test
    public void testFindAllByUser_UserHasOrders() {
        Order order1 = new Order();
        Order order2 = new Order();
        List<Order> orders = Arrays.asList(order1, order2);
        when(orderRepository.findAllByUserId(anyLong())).thenReturn(orders);

        ResponseEntity<List<Order>> response = orderService.findAllByUser(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(orders, response.getBody());
        verify(orderRepository, times(1)).findAllByUserId(1L);
    }

    @Test
    public void testDeleteAllByUserID_UserHasOrders() {
        Order order1 = new Order();
        order1.setStatus(Status.NEW);
        Order order2 = new Order();
        order2.setStatus(Status.CANCELLED);
        List<Order> orders = Arrays.asList(order1, order2);
        when(orderRepository.existsByUserId(anyLong())).thenReturn(true);
        when(orderRepository.findAllByUserId(anyLong())).thenReturn(orders);

        ResponseEntity<HttpStatus> response = orderService.deleteAllByUserID(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(orderRepository, times(1)).existsByUserId(1L);
        verify(orderRepository, times(1)).findAllByUserId(1L);
        verify(orderRepository, times(1)).deleteAllByUserId(1L);
    }

    @Test
    public void testDeleteAllByUserID_UserNotExists() {
        when(orderRepository.existsByUserId(anyLong())).thenReturn(false);

        ResponseEntity<HttpStatus> response = orderService.deleteAllByUserID(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(orderRepository, times(1)).existsByUserId(1L);
        verify(orderRepository, never()).findAllByUserId(anyLong());
        verify(orderRepository, never()).deleteAllByUserId(anyLong());
    }
    @Test
    public void testDeleteById_OrderExistsAndNotCancelled() {
        Order order = new Order();
        order.setStatus(Status.NEW);
        order.setProductList(List.of(new Product(), new Product()));

        when(orderRepository.existsById(anyLong())).thenReturn(true);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        ResponseEntity<?> response = orderService.deleteById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(orderRepository, times(1)).existsById(1L);
        verify(orderRepository, times(1)).findById(1L);
        verify(orderRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteById_OrderExistsAndCancelled() {
        Order order = new Order();
        order.setStatus(Status.CANCELLED);

        when(orderRepository.existsById(anyLong())).thenReturn(true);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(order));

        ResponseEntity<?> response = orderService.deleteById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(orderRepository, times(1)).existsById(1L);
        verify(orderRepository, times(1)).findById(1L);
        verify(orderRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteById_OrderNotExists() {
        when(orderRepository.existsById(anyLong())).thenReturn(false);

        ResponseEntity<?> response = orderService.deleteById(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(orderRepository, times(1)).existsById(1L);
        verify(orderRepository, never()).findById(anyLong());
        verify(orderRepository, never()).deleteById(anyLong());
    }

    @Test
    public void testCreateById_UserNotFound() {
        OrderRequestById orderRequestById = new OrderRequestById();
        orderRequestById.setOrderDate(LocalDateTime.now());
        orderRequestById.setProducts(new ArrayList<>());

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        ResponseEntity<?> response = orderService.createById(1L, orderRequestById, null);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("User not found", response.getBody());
    }
    @Test
    public void testCreateById_ProductNotAvailable() {

        ProductRequestById productRequestById = new ProductRequestById();
        productRequestById.setProductId(1L);
        productRequestById.setQuantity(2);

        OrderRequestById orderRequestById = new OrderRequestById();
        orderRequestById.setOrderDate(LocalDateTime.now());
        orderRequestById.setProducts(List.of(productRequestById));

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        Product unavailableProduct = new Product();
        unavailableProduct.setId(1L);
        unavailableProduct.setQuantity(0);
        unavailableProduct.setPrice(0.0);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(List.of(unavailableProduct), HttpStatus.OK));

        ResponseEntity<?> response = orderService.createById(1L, orderRequestById, null);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("The product - 1 - is not available in the store\n", response.getBody());
    }

    @Test
    public void testCreateById_InsufficientProductQuantity() {
        ProductRequestById productRequestById = new ProductRequestById();
        productRequestById.setProductId(1L);
        productRequestById.setQuantity(2);

        OrderRequestById orderRequestById = new OrderRequestById();
        orderRequestById.setOrderDate(LocalDateTime.now());
        orderRequestById.setProducts(List.of(productRequestById));

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        Product insufficientProduct = new Product();
        insufficientProduct.setId(1L);
        insufficientProduct.setQuantity(1);
        insufficientProduct.setPrice(100.0);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(List.of(insufficientProduct), HttpStatus.OK));

        ResponseEntity<?> response = orderService.createById(1L, orderRequestById, null);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("The maximum quantity of the product - 1 -  is equal to 1\n", response.getBody());
    }

    @Test
    public void testCreateById_OrderCreationSuccess() {
        ProductRequestById productRequestById = new ProductRequestById();
        productRequestById.setProductId(1L);
        productRequestById.setQuantity(2);

        OrderRequestById orderRequestById = new OrderRequestById();
        orderRequestById.setOrderDate(LocalDateTime.now());
        orderRequestById.setProducts(List.of(productRequestById));

        List<Product> products = new ArrayList<>();
        Product product = new Product();
        product.setId(1L);
        product.setName("Test Product");
        product.setDescription("Test Description");
        product.setPrice(100.0);
        product.setQuantity(10);
        products.add(product);

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(products, HttpStatus.OK));

        when(orderRepository.save(any(Order.class))).thenReturn(new Order());
        when(productRepository.saveAll(anyList())).thenReturn(products);

        ResponseEntity<?> response = orderService.createById(1L, orderRequestById, null);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void testCreateById_SaveError() {
        ProductRequestById productRequestById = new ProductRequestById();
        productRequestById.setProductId(1L);
        productRequestById.setQuantity(2);

        OrderRequestById orderRequestById = new OrderRequestById();
        orderRequestById.setOrderDate(LocalDateTime.now());
        orderRequestById.setProducts(List.of(productRequestById));

        List<Product> products = new ArrayList<>();
        Product product = new Product();
        product.setId(1L);
        product.setName("Test Product");
        product.setDescription("Test Description");
        product.setPrice(100.0);
        product.setQuantity(10);
        products.add(product);

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(products, HttpStatus.OK));

        when(orderRepository.save(any(Order.class))).thenThrow(new RuntimeException("Save error"));

        ResponseEntity<?> response = orderService.createById(1L, orderRequestById, null);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Save error", response.getBody());
    }

    @Test
    public void testCreateByName_UserNotFound() {
        OrderRequestByName orderRequestByName = new OrderRequestByName();
        orderRequestByName.setOrderDate(LocalDateTime.now());
        orderRequestByName.setProducts(new ArrayList<>());

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        ResponseEntity<?> response = orderService.createByName(1L, orderRequestByName, null);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("User not found", response.getBody());
    }

    @Test
    public void testCreateByName_ProductNotAvailable() {
        ProductRequestByName productRequestByName = new ProductRequestByName();
        productRequestByName.setName("Test Product");
        productRequestByName.setQuantity(2);

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        orderRequestByName.setOrderDate(LocalDateTime.now());
        orderRequestByName.setProducts(List.of(productRequestByName));

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        Product unavailableProduct = new Product();
        unavailableProduct.setName("Test Product");
        unavailableProduct.setQuantity(0);
        unavailableProduct.setPrice(0.0);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(List.of(unavailableProduct), HttpStatus.OK));

        ResponseEntity<?> response = orderService.createByName(1L, orderRequestByName, null);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("The product - Test Product - is not available in the store\n", response.getBody());
    }

    @Test
    public void testCreateByName_InsufficientProductQuantity() {
        ProductRequestByName productRequestByName = new ProductRequestByName();
        productRequestByName.setName("Test Product");
        productRequestByName.setQuantity(2);

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        orderRequestByName.setOrderDate(LocalDateTime.now());
        orderRequestByName.setProducts(List.of(productRequestByName));

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        Product insufficientProduct = new Product();
        insufficientProduct.setName("Test Product");
        insufficientProduct.setQuantity(1);
        insufficientProduct.setPrice(100.0);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(List.of(insufficientProduct), HttpStatus.OK));

        ResponseEntity<?> response = orderService.createByName(1L, orderRequestByName, null);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("The maximum quantity of the product - Test Product -  is equal to 1\n", response.getBody());
    }

    @Test
    public void testCreateByName_OrderCreationSuccess() {
        ProductRequestByName productRequestByName = new ProductRequestByName();
        productRequestByName.setName("Test Product");
        productRequestByName.setQuantity(2);

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        orderRequestByName.setOrderDate(LocalDateTime.now());
        orderRequestByName.setProducts(List.of(productRequestByName));

        List<Product> products = new ArrayList<>();
        Product product = new Product();
        product.setName("Test Product");
        product.setDescription("Test Description");
        product.setPrice(100.0);
        product.setQuantity(10);
        products.add(product);

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(products, HttpStatus.OK));

        when(orderRepository.save(any(Order.class))).thenReturn(new Order());
        when(productRepository.saveAll(anyList())).thenReturn(products);

        ResponseEntity<?> response = orderService.createByName(1L, orderRequestByName, null);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void testCreateByName_SaveError() {

        ProductRequestByName productRequestByName = new ProductRequestByName();
        productRequestByName.setName("Test Product");
        productRequestByName.setQuantity(2);

        OrderRequestByName orderRequestByName = new OrderRequestByName();
        orderRequestByName.setOrderDate(LocalDateTime.now());
        orderRequestByName.setProducts(List.of(productRequestByName));

        List<Product> products = new ArrayList<>();
        Product product = new Product();
        product.setName("Test Product");
        product.setDescription("Test Description");
        product.setPrice(100.0);
        product.setQuantity(10);
        products.add(product);

        ResponseEntity<String> userResponse = new ResponseEntity<>(HttpStatus.OK);
        when(restTemplate.getForEntity(anyString(), eq(String.class))).thenReturn(userResponse);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(products, HttpStatus.OK));

        when(orderRepository.save(any(Order.class))).thenThrow(new RuntimeException("Save error"));

        ResponseEntity<?> response = orderService.createByName(1L, orderRequestByName, null);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Save error", response.getBody());
    }


}

