package com.shop.userservice;
import com.shop.userservice.model.User;
import com.shop.userservice.repository.UserRepository;
import com.shop.userservice.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest {
    @Mock
    private UserRepository userRepository;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private UserService userService;
    private String orderUrl = "order-service";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateUser_UserCreated() {
        User user = new User(1L, "Asankin Andrey Mihailovich", LocalDateTime.now(), "Saransk 123 street");

        when(userRepository.existsById(user.getId())).thenReturn(false);
        when(userRepository.save(user)).thenReturn(user);

        ResponseEntity<User> response = userService.createUser(user);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(user, response.getBody());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testCreateUser_UserAlreadyExists() {
        User existingUser = new User(1L, "Asankin Andrey Mihailovich", LocalDateTime.now(), "Saransk 123 street");

        when(userRepository.existsById(existingUser.getId())).thenReturn(true);
        when(userRepository.findById(existingUser.getId())).thenReturn(Optional.of(existingUser));

        ResponseEntity<User> response = userService.createUser(existingUser);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(Optional.of(existingUser), response.getBody());
        verify(userRepository, never()).save(existingUser);
    }

    @Test
    void testGetUser_UserFound() {
        User user = new User(1L, "Asankin Andrey Mihailovich", LocalDateTime.now(), "Saransk 123 street");

        when(userRepository.existsById(user.getId())).thenReturn(true);
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        ResponseEntity<User> response = userService.getUser(user.getId());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Optional.of(user), response.getBody());
        verify(userRepository, times(1)).findById(user.getId());
    }

    @Test
    void testGetUser_UserNotFound() {
        long nonExistingUserId = 999L;

        when(userRepository.existsById(nonExistingUserId)).thenReturn(false);

        ResponseEntity<User> response = userService.getUser(nonExistingUserId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        verify(userRepository, times(1)).existsById(nonExistingUserId);
        verify(userRepository, never()).findById(nonExistingUserId);
    }

    @Test
    void testDeleteUser_UserDeleted() {
        long userIdToDelete = 1L;
        User userToDelete = new User(1L, "Asankin Andrey Mihailovich", LocalDateTime.now(), "Saransk 123 street");

        when(userRepository.findById(userIdToDelete)).thenReturn(Optional.of(userToDelete));

        ResponseEntity<HttpStatus> response = userService.deleteUser(userIdToDelete);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userRepository, times(1)).deleteById(userIdToDelete);
    }

    @Test
    void testDeleteUser_UserNotFound() {
        long nonExistingUserId = 999L;

        when(userRepository.findById(nonExistingUserId)).thenReturn(Optional.empty());

        ResponseEntity<HttpStatus> response = userService.deleteUser(nonExistingUserId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(userRepository, times(1)).findById(nonExistingUserId);
        verify(userRepository, never()).deleteById(nonExistingUserId);
    }

    @Test
    void testGetAllUsers() {
        User user1 = new User(1L, "Asankin Andrey Mihailovich", LocalDateTime.now(), "Saransk 123 street");
        User user2 = new User(2L, "Asankin Anton Mihailovich", LocalDateTime.now(), "Saransk 123 street");

        List<User> userList = Arrays.asList(user1, user2);

        when(userRepository.findAll()).thenReturn(userList);

        ResponseEntity<List<User>> response = userService.getAllUsers();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userList, response.getBody());
        verify(userRepository, times(1)).findAll();
    }

    @Test
    void testUpdateUser_UserUpdated() {
        long userIdToUpdate = 1L;
        User updatedUser = new User(userIdToUpdate, "Updated Name", LocalDateTime.now(), "Updated Address");

        when(userRepository.findById(userIdToUpdate)).thenReturn(Optional.of(new User(userIdToUpdate, "Old Name", LocalDateTime.now(), "Old Address")));
        when(userRepository.save(updatedUser)).thenReturn(updatedUser);

        ResponseEntity<User> response = userService.updateUser(userIdToUpdate, updatedUser);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedUser, response.getBody());
        verify(userRepository, times(1)).findById(userIdToUpdate);
        verify(userRepository, times(1)).save(updatedUser);
    }

    @Test
    void testUpdateUser_UserNotFound() {
        long nonExistingUserId = 999L;
        User updatedUser = new User(nonExistingUserId, "Updated Name", LocalDateTime.now(), "Updated Address");

        when(userRepository.findById(nonExistingUserId)).thenReturn(Optional.empty());

        ResponseEntity<User> response = userService.updateUser(nonExistingUserId, updatedUser);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(userRepository, times(1)).findById(nonExistingUserId);
        verify(userRepository, never()).save(updatedUser);
    }

}