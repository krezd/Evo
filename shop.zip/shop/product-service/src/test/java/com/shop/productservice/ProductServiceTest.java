package com.shop.productservice;
import com.shop.productservice.model.Product;
import com.shop.productservice.dto.ProductResponseById;
import com.shop.productservice.dto.ProductResponseByName;
import com.shop.productservice.repository.ProductRepository;
import com.shop.productservice.service.ProductService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindAll() {
        List<Product> products = Arrays.asList(
                new Product(1L, "Product1", "Description1", 100.0, 10),
                new Product(2L, "Product2", "Description2", 200.0, 20)
        );

        when(productRepository.findAll()).thenReturn(products);

        ResponseEntity<List<Product>> response = productService.findAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(products, response.getBody());
        verify(productRepository, times(1)).findAll();
    }

    @Test
    void testGetProductById_ProductFound() {
        Optional<Product> product = Optional.of(new Product(1L, "Product1", "Description1", 100.0, 10));
        when(productRepository.findById(1L)).thenReturn(product);
        when(productRepository.existsById(1L)).thenReturn(true);

        ResponseEntity<Product> response = productService.getProductById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals( product, response.getBody());
        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, times(1)).existsById(1L);

    }

    @Test
    void testGetProductById_ProductNotFound() {
        when(productRepository.existsById(1L)).thenReturn(false);

        ResponseEntity<Product> response = productService.getProductById(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        verify(productRepository, times(1)).existsById(1L);
    }

    @Test
    void testGetProductByName() {
        List<Product> products = Arrays.asList(
                new Product(1L, "Product1", "Description1", 100.0, 10),
                new Product(2L, "Product1", "Description2", 200.0, 20)
        );

        when(productRepository.findAllByName("Product1")).thenReturn(products);

        ResponseEntity<List<Product>> response = productService.getProductByName("Product1");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(products, response.getBody());
        verify(productRepository, times(1)).findAllByName("Product1");
    }

    @Test
    void testCreateProduct_ProductAlreadyExists() {
        Product product = new Product(1L, "Product1", "Description1", 100.0, 10);
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(productRepository.existsById(1L)).thenReturn(true);
        ResponseEntity<Product> response = productService.createProduct(product);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(Optional.of(product), response.getBody());
        verify(productRepository, times(1)).existsById(1L);
        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void testCreateProduct_NewProduct() {
        Product product = new Product(1L, "Product1", "Description1", 100.0, 10);
        when(productRepository.existsById(1L)).thenReturn(false);
        when(productRepository.save(product)).thenReturn(product);

        ResponseEntity<Product> response = productService.createProduct(product);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(product, response.getBody());
        verify(productRepository, times(1)).existsById(1L);
        verify(productRepository, times(1)).save(product);
    }

    @Test
    void testUpdateProduct_ProductFound() {
        Product existingProduct = new Product(1L, "ExistingProduct", "Description1", 100.0, 10);
        Product updatedProduct = new Product(1L, "UpdatedProduct", "Description2", 200.0, 20);

        when(productRepository.findById(1L)).thenReturn(Optional.of(existingProduct));
        when(productRepository.save(updatedProduct)).thenReturn(updatedProduct);

        ResponseEntity<Product> response = productService.updateProduct(1L, updatedProduct);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedProduct, response.getBody());
        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, times(1)).save(updatedProduct);
    }

    @Test
    void testUpdateProduct_ProductNotFound() {
        Product updatedProduct = new Product(1L, "UpdatedProduct", "Description2", 200.0, 20);
        when(productRepository.findById(1L)).thenReturn(Optional.empty());

        ResponseEntity<Product> response = productService.updateProduct(1L, updatedProduct);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void testDeleteProduct_ProductFound() {
        Product product = new Product(1L, "Product1", "Description1", 100.0, 10);
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));

        ResponseEntity<HttpStatus> response = productService.deleteProduct(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteProduct_ProductNotFound() {
        when(productRepository.findById(1L)).thenReturn(Optional.empty());

        ResponseEntity<HttpStatus> response = productService.deleteProduct(1L);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, never()).deleteById(1L);
    }


    @Test
    public void testGetDataToOrderByName_ProductNotFound(){
        List<ProductResponseByName> productResponsByNames = new ArrayList<>();
        productResponsByNames.add(new ProductResponseByName("Товар1", 5));
        List<Product> tempProducts = new ArrayList<>();
        tempProducts.add(new Product(1L, "Товар2", "Описание", 10, 2)); // Пример данных
        when(productRepository.existsByName("False")).thenReturn(true);
        when(productRepository.findAll()).thenReturn(tempProducts);

        List<Product> result = productService.getDataToOrderByName(productResponsByNames);
        assertEquals(1, result.size()); // Проверяем размер списка
        assertEquals("Товар1", result.get(0).getName()); // Проверяем имя первого товара
        assertEquals(0, result.get(0).getQuantity()); // Проверяем количество первого товара
        assertEquals(0, result.get(0).getPrice()); // Проверяем цену первого товара

    }


        @Test
    public void testGetDataToOrderByName_ProductFoundLessThenNeed(){
        List<ProductResponseByName> productResponsByNames = new ArrayList<>();
        productResponsByNames.add(new ProductResponseByName("Товар1", 5));
        productResponsByNames.add(new ProductResponseByName("Товар2", 12));
        productResponsByNames.add(new ProductResponseByName("Товар3", 3));

        List<Product> tempProducts = new ArrayList<>();
        tempProducts.add(new Product(1L, "Товар1", "Описание", 10, 2)); // Пример данных
        tempProducts.add(new Product(2L, "Товар1", "Описание", 4, 1)); // Пример данных
        List<Product> tempProducts2 = new ArrayList<>();
        tempProducts2.add(new Product(3L, "Товар2", "Описание", 10, 3)); // Пример данных
        tempProducts2.add(new Product(4L, "Товар2", "Описание", 23, 2)); // Пример данных
        List<Product> tempProducts3 = new ArrayList<>();
        tempProducts3.add(new Product(5L, "Товар3", "Описание", 10, 1)); // Пример данных
        tempProducts3.add(new Product(6L, "Товар3", "Описание", 14, 1)); // Пример данных

        when(productRepository.existsByName("Товар1")).thenReturn(true);
        when(productRepository.findAllByName("Товар1")).thenReturn(tempProducts);

        when(productRepository.existsByName("Товар2")).thenReturn(true);
        when(productRepository.findAllByName("Товар2")).thenReturn(tempProducts2);

        when(productRepository.existsByName("Товар3")).thenReturn(true);
        when(productRepository.findAllByName("Товар3")).thenReturn(tempProducts3);

        List<Product> result = productService.getDataToOrderByName(productResponsByNames);
        assertEquals(3, result.size()); // Проверяем размер списка
        assertEquals("Товар1", result.get(0).getName()); // Проверяем имя первого товара
        assertEquals(2, result.get(0).getQuantity()); // Проверяем количество первого товара
        assertEquals(10, result.get(0).getPrice()); // Проверяем цену первого товара

        assertEquals("Товар2", result.get(1).getName()); // Проверяем имя первого товара
        assertEquals(3, result.get(1).getQuantity()); // Проверяем количество первого товара
        assertEquals(10, result.get(1).getPrice()); // Проверяем цену первого товара

        assertEquals("Товар3", result.get(2).getName()); // Проверяем имя первого товара
        assertEquals(1, result.get(2).getQuantity()); // Проверяем количество первого товара
        assertEquals(10, result.get(2).getPrice()); // Проверяем цену первого товара

        verify(productRepository, times(1)).existsByName("Товар1");
        verify(productRepository, times(1)).findAllByName("Товар1");

        verify(productRepository, times(1)).existsByName("Товар2");
        verify(productRepository, times(1)).findAllByName("Товар2");

        verify(productRepository, times(1)).existsByName("Товар2");
        verify(productRepository, times(1)).findAllByName("Товар2");
    }



    @Test
    public void testGetDataToOrderByName() {
        List<ProductResponseByName> productResponsByNames = new ArrayList<>();
        productResponsByNames.add(new ProductResponseByName("Товар1", 5));
        productResponsByNames.add(new ProductResponseByName("Товар2", 12));
        productResponsByNames.add(new ProductResponseByName("Товар3", 3));

        List<Product> tempProducts = new ArrayList<>();
        tempProducts.add(new Product(1L, "Товар1", "Описание", 10, 100)); // Пример данных
        tempProducts.add(new Product(2L, "Товар1", "Описание", 4, 100)); // Пример данных
        List<Product> tempProducts2 = new ArrayList<>();
        tempProducts2.add(new Product(3L, "Товар2", "Описание", 10, 5)); // Пример данных
        tempProducts2.add(new Product(4L, "Товар2", "Описание", 23, 13)); // Пример данных
        List<Product> tempProducts3 = new ArrayList<>();
        tempProducts3.add(new Product(5L, "Товар3", "Описание", 10, 5)); // Пример данных
        tempProducts3.add(new Product(6L, "Товар3", "Описание", 14, 3)); // Пример данных

        when(productRepository.existsByName("Товар1")).thenReturn(true);
        when(productRepository.findAllByName("Товар1")).thenReturn(tempProducts);
        when(productRepository.findById(2L)).thenReturn(Optional.ofNullable(tempProducts.get(1)));

        when(productRepository.existsByName("Товар2")).thenReturn(true);
        when(productRepository.findAllByName("Товар2")).thenReturn(tempProducts2);
        when(productRepository.findById(4L)).thenReturn(Optional.ofNullable(tempProducts2.get(1)));

        when(productRepository.existsByName("Товар3")).thenReturn(true);
        when(productRepository.findAllByName("Товар3")).thenReturn(tempProducts3);
        when(productRepository.findById(5L)).thenReturn(Optional.ofNullable(tempProducts3.get(0)));


        List<Product> result = productService.getDataToOrderByName(productResponsByNames);
        assertEquals(3, result.size()); // Проверяем размер списка
        assertEquals("Товар1", result.get(0).getName()); // Проверяем имя первого товара
        assertEquals(5, result.get(0).getQuantity()); // Проверяем количество первого товара
        assertEquals(4, result.get(0).getPrice()); // Проверяем цену первого товара

        assertEquals("Товар2", result.get(1).getName()); // Проверяем имя первого товара
        assertEquals(12, result.get(1).getQuantity()); // Проверяем количество первого товара
        assertEquals(23, result.get(1).getPrice()); // Проверяем цену первого товара

        assertEquals("Товар3", result.get(2).getName()); // Проверяем имя первого товара
        assertEquals(3, result.get(2).getQuantity()); // Проверяем количество первого товара
        assertEquals(10, result.get(2).getPrice()); // Проверяем цену первого товара

        verify(productRepository, times(1)).existsByName("Товар1");
        verify(productRepository, times(1)).findAllByName("Товар1");

        verify(productRepository, times(1)).existsByName("Товар2");
        verify(productRepository, times(1)).findAllByName("Товар2");

        verify(productRepository, times(1)).existsByName("Товар2");
        verify(productRepository, times(1)).findAllByName("Товар2");
    }

    @Test
    public void testGetDataToOrderById() {
        List<ProductResponseById> productResponsById = new ArrayList<>();
        productResponsById.add(new ProductResponseById(1L, 5));
        productResponsById.add(new ProductResponseById(2L, 12));

        Product dbProduct1 = new Product(1L, "Товар1", "Описание", 10, 100); // Пример данных
        Product dbProduct2 = new Product(2L, "Товар2", "Описание", 10, 5); // Пример данных

        when(productRepository.existsById(1L)).thenReturn(true);
        when(productRepository.existsById(2L)).thenReturn(true);
        when(productRepository.findById(1L)).thenReturn(Optional.of(dbProduct1));
        when(productRepository.findById(2L)).thenReturn(Optional.of(dbProduct2));

        List<Product> result = productService.getDataToOrderById(productResponsById);
        assertEquals(2, result.size()); // Проверяем размер списка
        assertEquals(1L, result.get(0).getId()); // Проверяем имя первого товара
        assertEquals(5, result.get(0).getQuantity()); // Проверяем количество первого товара
        assertEquals(10, result.get(0).getPrice()); // Проверяем цену первого товара

        assertEquals(2L, result.get(1).getId()); // Проверяем имя первого товара
        assertEquals(5, result.get(1).getQuantity()); // Проверяем количество первого товара
        assertEquals(10, result.get(1).getPrice()); // Проверяем цену первого товара

        verify(productRepository, times(1)).findById(1L);
        verify(productRepository, times(1)).findById(2L);
        verify(productRepository, times(1)).existsById(1L);
        verify(productRepository, times(1)).existsById(2L);

    }

    @Test
    void testChangeQuantity_ReturnOperation() {
        Product product1 = new Product();
        product1.setId(1L);
        product1.setQuantity(5);

        Product product2 = new Product();
        product2.setId(2L);
        product2.setQuantity(3);

        Product dbProduct1 = new Product();
        dbProduct1.setId(1L);
        dbProduct1.setQuantity(10);

        Product dbProduct2 = new Product();
        dbProduct2.setId(2L);
        dbProduct2.setQuantity(8);

        when(productRepository.findById(1L)).thenReturn(Optional.of(dbProduct1));
        when(productRepository.findById(2L)).thenReturn(Optional.of(dbProduct2));

        List<Product> products = Arrays.asList(product1, product2);
        productService.changeQuantity(products, "return");

        assertEquals(15, dbProduct1.getQuantity());
        assertEquals(11, dbProduct2.getQuantity());

        verify(productRepository, times(1)).save(dbProduct1);
        verify(productRepository, times(1)).save(dbProduct2);
    }

    @Test
    void testChangeQuantity_WriteOffOperation() {
        Product product1 = new Product();
        product1.setId(1L);
        product1.setQuantity(5);

        Product product2 = new Product();
        product2.setId(2L);
        product2.setQuantity(3);

        Product dbProduct1 = new Product();
        dbProduct1.setId(1L);
        dbProduct1.setQuantity(10);

        Product dbProduct2 = new Product();
        dbProduct2.setId(2L);
        dbProduct2.setQuantity(8);

        when(productRepository.findById(1L)).thenReturn(Optional.of(dbProduct1));
        when(productRepository.findById(2L)).thenReturn(Optional.of(dbProduct2));

        List<Product> products = Arrays.asList(product1, product2);
        productService.changeQuantity(products, "writeOff");

        assertEquals(5, dbProduct1.getQuantity());
        assertEquals(5, dbProduct2.getQuantity());

        verify(productRepository, times(1)).save(dbProduct1);
        verify(productRepository, times(1)).save(dbProduct2);
    }

    @Test
    void testChangeQuantity_ProductNotFound() {
        Product product1 = new Product();
        product1.setId(1L);
        product1.setQuantity(5);

        when(productRepository.findById(1L)).thenReturn(Optional.empty());

        List<Product> products = Arrays.asList(product1);

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            productService.changeQuantity(products, "return");
        });

        assertEquals("Product with id 1 not found", exception.getMessage());
    }

}

