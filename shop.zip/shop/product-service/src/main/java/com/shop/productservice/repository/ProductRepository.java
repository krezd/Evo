package com.shop.productservice.repository;

import com.shop.productservice.model.Product;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {
    List<Product> findAllByName(String name);
    boolean existsByName(String name);
    boolean existsById(Long id);
}
