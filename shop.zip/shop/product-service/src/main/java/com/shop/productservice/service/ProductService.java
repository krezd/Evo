package com.shop.productservice.service;

import com.shop.productservice.model.Product;
import com.shop.productservice.dto.ProductResponseById;
import com.shop.productservice.dto.ProductResponseByName;
import com.shop.productservice.repository.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;


    public ResponseEntity<List<Product>> findAll() {
        return new ResponseEntity(productRepository.findAll(), HttpStatus.OK);
    }

    public ResponseEntity<Product> getProductById(Long id) {
        if (productRepository.existsById(id)) {
            return new ResponseEntity(productRepository.findById(id), HttpStatus.OK);
        }
        return new ResponseEntity(HttpStatus.NOT_FOUND);
    }

    public ResponseEntity<List<Product>> getProductByName(String name) {
        return new ResponseEntity(productRepository.findAllByName(name), HttpStatus.OK);
    }


    public ResponseEntity<Product> createProduct(Product product) {
        if (!productRepository.existsById(product.getId())) {
            return new ResponseEntity(productRepository.save(product), HttpStatus.CREATED);
        }
        return new ResponseEntity(productRepository.findById(product.getId()), HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<Product> updateProduct(Long id, Product product) {
        if (productRepository.findById(id).isPresent()) {
            product.setId(id);
            productRepository.save(product);
            return new ResponseEntity(product, HttpStatus.OK);
        }
        return new ResponseEntity(HttpStatus.NOT_FOUND);
    }


    public ResponseEntity<HttpStatus> deleteProduct(Long id) {
        if (productRepository.findById(id).isPresent()) {
            productRepository.deleteById(id);
            return new ResponseEntity(HttpStatus.OK);
        }
        return new ResponseEntity(HttpStatus.NOT_FOUND);
    }

    //Передача товаров в заказ по id товара
    public List<Product> getDataToOrderById(List<ProductResponseById> productResponseById) {
        List<Product> products = new ArrayList<>();
        Boolean flag = true; // Флаг, сигнализирующий, что заказ полностью исполним(хватает товаров на складе)
        for (ProductResponseById response : productResponseById) {
            if (productRepository.existsById(response.getProductId())) {
                Product tempProduct = new Product(productRepository.findById(response.getProductId()).orElse(null));
                //Проверка количества товара
                if (tempProduct.getQuantity() < response.getQuantity()) {
                    flag = false;
                } else {
                    tempProduct.setQuantity(response.getQuantity());//Установка нужного кол-во товара
                }
                products.add(tempProduct);
            } else {
                //Иначе возвращаем пустой товар
                products.add(new Product(response.getProductId(), "NotFound", "", 0, 0));
                flag = false;
            }
        }
        //Уменьшаем количество товаров на складе в случае успешного оформления заказа
        if (flag) {
            changeQuantity(products, "writeOff");
        }
        return products;
    }
    //Передача товаров в заказ по названию товара
    public List<Product> getDataToOrderByName(List<ProductResponseByName> productResponseByName) {
        List<Product> products = new ArrayList<>();

        Boolean flag = true; // Флаг, сигнализирующий, что заказ полностью исполним(хватает товаров на складе)
        for (ProductResponseByName response : productResponseByName) {
            if (productRepository.existsByName(response.getName())) {
                List<Product> tempProduct = productRepository.findAllByName(response.getName());
                Product minProduct = new Product(tempProduct.stream().max(Comparator.comparingInt(Product::getQuantity)).orElse(tempProduct.get(0)));
                for (Product product1 : tempProduct) {
                    if (product1.getQuantity() >= response.getQuantity() && product1.getPrice() <= minProduct.getPrice()) {
                        minProduct = product1.clone();
                        minProduct.setQuantity(response.getQuantity());

                    }
                }
                if (minProduct.getQuantity() < response.getQuantity()) {
                    flag = false;
                }
                products.add(minProduct);
            } else {
                //Иначе возвращаем пустой товар
                products.add(new Product(0, response.getName(), "", 0, 0));
                flag = false;
            }
        }
        //Уменьшаем количество товаров на складе в случае успешного оформления заказа
        if (flag) {
            changeQuantity(products, "writeOff");
        }
        return products;
    }

    public void changeQuantity(List<Product> products, String operation) {
        //Проходим по каждому товару в списке и проводим операцию возврата/списания товара
        for (Product product : products) {
            Product tempProduct = productRepository.findById(product.getId())
                    .orElseThrow(() ->
                            new EntityNotFoundException
                                    ("Product with id " + product.getId() + " not found"));
            if (Objects.equals(operation, "return")) {
                tempProduct.setQuantity(tempProduct.getQuantity() + product.getQuantity());
            } else if (Objects.equals(operation, "writeOff")) {
                tempProduct.setQuantity(tempProduct.getQuantity() - product.getQuantity());
            }
            productRepository.save(tempProduct);
        }
    }
}



