package com.shop.productservice.controller;

import com.shop.productservice.model.Product;
import com.shop.productservice.dto.ProductResponseById;
import com.shop.productservice.dto.ProductResponseByName;
import com.shop.productservice.service.ProductService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductService productService;

    //TODO написать тесты, подключить эврику, дописать логику c заказами, написать комментарии

    @GetMapping()
    public ResponseEntity<List<Product>> getProducts() {
        return productService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProduct(@PathVariable long id) {
        return productService.getProductById(id);
    }

    @GetMapping("/name")
    public ResponseEntity<List<Product>> getProductByName(@RequestParam String name) {
        return productService.getProductByName(name);
    }

    @PostMapping()
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        return productService.createProduct(product);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable long id, @RequestBody Product product) {
        return productService.updateProduct(id, product);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable long id) {
        return productService.deleteProduct(id);
    }
    //Контроллер, который принимает запрос на товары и отдает их на сервис заказа
    @PostMapping("/getDataToOrderByName")
    public List<Product> getDataToOrderByName(@RequestBody List<ProductResponseByName> productResponseByName) {
        return productService.getDataToOrderByName(productResponseByName);
    }

    //Контроллер, который принимает запрос на товары и отдает их на сервис заказа
    @PostMapping("/getDataToOrderById")
    public List<Product> getDataToOrderById(@RequestBody List<ProductResponseById> productResponseById) {
        return productService.getDataToOrderById(productResponseById);
    }

    //Контроллер, который возвращает товары в бд
    @PostMapping("/returnProduct")
    public ResponseEntity<String> changeQuantity(@RequestBody List<Product> products) {
        try {
            productService.changeQuantity(products, "return");
            return ResponseEntity.ok("Successfully updated product quantities");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to return product quantities: " + e.getMessage());
        }
    }
}

